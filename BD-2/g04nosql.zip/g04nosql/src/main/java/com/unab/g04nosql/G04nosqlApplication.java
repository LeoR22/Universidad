package com.unab.g04nosql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class G04nosqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(G04nosqlApplication.class, args);
	}

}
