package com.unab.g04nosql.IRepository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.unab.g04nosql.Collection.Persons;

public interface IPersonsRepository extends MongoRepository<Persons, String> {

}
