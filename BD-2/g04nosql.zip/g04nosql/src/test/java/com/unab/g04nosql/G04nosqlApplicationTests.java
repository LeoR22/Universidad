package com.unab.g04nosql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class G04nosqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
