const util = require('./scripts/computos')

const express = require('express')

const app = express()
const port = 1234

// arreglo para almacenar los datos de cada procesamiento
let infoCuotas = [];

app.use(express.urlencoded({extended: true}))

// define que la carpeta public tendrá recursos publicos



/*
    lógica para peticiones get
    Regresa la pagina index.html
    . procesarEntrada() - para calcular cuota para la entrada dada
    . mostrarReporte1() - despliega el primer reporte solicitado
    . mostrarReporte1() - despliega el segundo reporte solicitado 
*/ 
app.get('XXX', (req,res)=> {
    console.log('en get/procesaCuota')
    res.sendFile(__dirname+"/static/index.html")
})

/*
    lógica para peticiones post
    Si la opcion solicitada desde la pagina web, es:
    . Calcular - calcula la cuota para la entrada dada y en la variable salida asigna
                 la información a desplegar
    . ListarTodos - en la variable salida asigna la información del primer reporte
    . diferente a las anteriores - en la variable salida asigna la información del segundo reporte

    Luego obtiene una pagina dinamica con los datos leidos y la informacion almacenada en salida,
    la cual retorna al navegador web
*/ 
app.post('XXX', (req,res)=> {
    console.log('en post/calculaCuota')
    /* 
       obtiene los datos suministrados desde el formulario, en las variables:
       nombre, prestamo, meses, interes
    */
    const datos = req.body;
	const opcion = datos.laOpcion;
    const nombre = datos.elNombre;
    const prestamo = datos.elPrestamo;
    // lee los datos restantes
    const meses = 12;
    const interes = 15.5;


    // obtiene en salida, la cadena a desplegar en el area de texto
    let salida=''
    switch (opcion){
        case "Calcular":
            const cuota = util.calcularCuotaMensual(prestamo, interes/100, meses );
            salida = `${nombre} debe pagar $ ${cuota.toFixed(2)} cada mes por el préstamo de $ ${prestamo} a ${meses} meses con el interés del ${interes*100}%`;

            // crea nuevo objeto con las propiedades nombre, prestamo, meses, interes y cuota
            // y lo almacena al inicio del arreglo infoCuotas
            let nvaCuota = {
                nombre,
                prestamo,
                meses,
                interes,
                cuota
            }

            infoCuotas.unshift(nvaCuota)
            break;    
        case "ListarTodos":
            // asigna en salida la cadena retornada por reporteTotal
            
            break;
        default:
            // asigna en salida la cadena retornada por reporteMasGanan
            
        }

        //obtiene string con la pagina HTML a retornar y la regresa
        const nPage = util.crearPagina(nombre, prestamo, meses, interes, salida);
        // retorna la pagina obtenida
        
})


app.listen(port, () => {
    console.log('Estoy ejecutandome en http://localhost:'+port+"/procesaCuota");
  })

