/*
    funcion crearPagina(nombre, prestamo, meses, interes, cadSalida)
    Retorna una pagina similar a index.html, pero con los inputs enviados como
    parametros y con la cadSalida en el area de texto la cadena cadSalida

    Nota: se debe asegurar que cadSalida sea desplegada y que el formulario
          genere una peticion post a la ruta procesaCuota
*/ 
function crearPagina(nombre, prestamo, meses, interes, cadSalida){
  return `<!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Simulador Financiero - UAO</title>
      <style>
        body{
            background-color: lightcyan;
            font-size: 20px;
            text-align: center;
        }

        textArea{
            width:600px;
            height:120px;
            border: 2px solid;
        }

        h1 {
            color: blue;
            font-size: 30px;
            font-family: 'Times New Roman', Times, serif;
        }

        section p{
            background-color: lightskyblue;
            margin: 5px 10px; 
            padding: 5px 10px;    
            font-size: 25px;
            border-radius: 20px;    
        }

        table {
            margin: 0 auto;
            border: 2px solid;
            text-align: center;
        }
    </style>
  </head>
  <body>
    <header>
      <h1>Caso1 - Computo de cuotas mensuales</h1>
    </header>
    <main>
      <section>
        <p>Este aplicativo permite el computo de la cuota mensual con los datos suministrados y la generación de un par de reportes</p>
        <!-- Ajustar la ruta y la peticion post -->
		<form action="XXXX" method = "yyy" enctype="application/x-www-form-urlencoded">
          <table>
              <caption>Simulador de Cuotas</caption>  
              <tr>
                  <td>Nombre</td>
                  <td>
                      <input type="text" value="${nombre}" name="elNombre">
                  </td>
              </tr>  
              <tr>
                  <td>Prestamo $</td>
                  <td>
                      <input type="number" value="${prestamo}" name="elPrestamo">
                  </td>
              </tr> 
              <tr>
                  <td>Interes (%)</td>
                  <td>
                      <input type="number" value="${interes}" name="elInteres">
                  </td>
              </tr>   
              <tr>
                  <td>Meses</td>
                  <td>
                      <input type="number" value="${meses}" name="losMeses">
                  </td>
              </tr>                                                         
          </table><br>
        <textarea name="laRespuesta" readonly>${cadSalida}</textarea><br>
        <select name="laOpcion">
            <option value="Calcular" selected>Calcular Cuota</option><!-- Opción por defecto -->
            <option value="ListarTodos">Listar todos</option> 
            <option value="ListarGanan">Listar ganan mas</option> 
        </select> 
        <button id="procesar" type="submit">Ejecutar funcionalidad</button>
      </form> 
    </section>
  </body>
</html>`;
}

function calcularCuotaMensual(prestamo, interes, meses){
  let aux = Math.pow((1 + interes), meses)
  let res = prestamo * ((interes * aux) / (aux - 1));
  return Math.round(res)
} 

function reporteTotal(info){
  let mensaje = "Listado prestamos procesados son:\n"
  info.forEach( x => mensaje += `${x.nombre} -- $${x.prestamo} -- $${x.cuota} -- ${x.meses} -- ${x.interes}%\n`)

  return mensaje
}

function reporteMasGanan(info){
  let mensaje = "Listado de préstamos por más de $1000000:\n"
  info.filter(x => x.prestamo>1000000).forEach( x => mensaje += `${x.nombre} -- $${x.prestamo} -- $${x.cuota}\n`)

  return mensaje
}

module.exports = {crearPagina, calcularCuotaMensual, reporteTotal, reporteMasGanan};